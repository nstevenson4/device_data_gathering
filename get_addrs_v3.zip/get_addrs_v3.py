from netmiko import ConnectHandler
import time
from getpass import getpass
import concurrent.futures

#Variable Declarations
device_list = input('Enter name of device list file: ').strip()
device_type =""
select_device= input("Type 'y' and press ENTER if this is a Cisco device List, otherwise just press ENTER: ").strip()

if select_device.lower() == "y":
    device_type = "cisco"
else:
    device_type = "juniper"

output_file = device_type + '_ip_list.txt'
start_time = time.perf_counter()
login = input('Username: ')
password = getpass('Password: ')

#Function to read values from a device IP list file
def get_net_devices():
    with open(device_list) as devices:
        addresses = devices.read().splitlines()
    return addresses

#Function that connects and pulls data from network devices
def get_device_data(address):
    border = "-----------------------------"
    spacer = "--"

    #Prompts user for either Juniper or Cisco credentials based on User input 
    if device_type == 'juniper':
        junos_device_info = {
           'ip': address,
           #'port': 22,
           'username': login,
           'password': password,
           'device_type': 'juniper',
           'verbose': True
        }
        print(f'Connecting to host {address}...')
        ssh_connection = ConnectHandler(**junos_device_info)
        host_name = ssh_connection.send_command("show configuration system host-name | display set | trim 21")
        output = ssh_connection.send_command('show configuration interfaces | match "desc|address" | trim 20')
        #version = ssh_connection.send_command('show version')
    else:
        secret = getpass('Enable Secret: ')
        cisco_device_info = {
           'ip': address,
           #'port': 22,
           'username': login,
           'password': password,
           'device_type': 'cisco_ios',
           'secret': secret,
           'verbose': True
        }
        print(f'Connecting to host {address}...')
        ssh_connection = ConnectHandler(**cisco_device_info)
        host_name = ssh_connection.send_command('show run | i hostname')
        output = ssh_connection.send_command('sh ip int bri | exclude unassigned|down')
        #desc = ssh_connection.send_command('sh int desc | ex down')
        
    #Creates text file displaying either the Juniper or Cisco data 
    with open(output_file, 'a+') as data_file:
       #time.sleep(1)
       data_file.write(border + "\n" + host_name + "" + spacer + "\n" + output + "" + border + "\n")
       #time.sleep(1)

    #Displays either the Juniper or Cisco data to the session terminal
    print(border + "\n" + host_name + "" + spacer + "\n" + output + "" + border + "\n")

    ssh_connection.disconnect()
    return

def main():
   with concurrent.futures.ThreadPoolExecutor() as exe:
      ip_addresses = get_net_devices()
      results = exe.map(get_device_data, ip_addresses)
      #print(results)

   finish_time = time.perf_counter()
   print(f'The script finished executing in {round(start_time - finish_time,2)} seconds.')

   exit_script = input("Close Window or Type 'y' and press 'Enter' to exit: ")
   exit_script = exit_script.lower()
   
   if exit_script == 'y':
       exit()

if __name__ == '__main__':
   main()