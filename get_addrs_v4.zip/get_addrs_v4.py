from netmiko import ConnectHandler
import time
from getpass import getpass
import concurrent.futures
import pprint

#Variable Declarations
device_list = input('Enter name of device list text file: ').strip()
command_list = []
output_file = 'juniper_ip_list.txt'
start_time = time.perf_counter()
login = input('Username: ')
password = getpass('Password: ')

#Function to read values from a device IP list file
def get_net_devices():
    with open(device_list) as devices:
        addresses = devices.read().splitlines()
    return addresses

def organize_output(show_commands):
   ip_list = []
   desc_list = []
   host = ''
   for line in show_commands:
       hostname_index = line.find("host-name")
       address_index = line.find("address")
       desc_index = line.find("description")
       sub_int = line.find("interfaces") + 11
       family = line.find("family")
       addr_marker = line[(sub_int):family]
       desc_marker = line[(sub_int):desc_index]
       hostname = ''
       ip_address = ''
       description = ''
       
       if (hostname_index != -1):
           show_config_hostname = line
           hostname = line[21:]
           host = hostname
           ip_list.append(show_config_hostname)

       if (address_index != -1):
           ip_address = line[(address_index + 8):]
           ip_list.append(addr_marker.strip() + host + " : " + host + "-" + ip_address)
   
       if(desc_index != -1):
           description = line[(desc_index + 12):]
           desc_list.append(desc_marker.strip() + host + " : " + description)
       
   for ip in ip_list:
       with open("final.txt", 'a+') as data_file:
           sub_marker = ip.find(" : ")
           hostname_index = ip.find("host-name")
           if (hostname_index != -1):
               show_config_hostname = ip[21:]
               #print(show_config_hostname)
          
               data_file.write("-----------------------------")
               data_file.write("\n")
               data_file.write(show_config_hostname)
               data_file.write("\n")
               data_file.write("--")
               data_file.write("\n")
        
           for descrip in desc_list:
               if ip[:sub_marker] == descrip[:sub_marker]:
                   sub_marker = sub_marker + 3
                   data_file.write(ip[sub_marker:] + " : " + descrip[sub_marker:])
                   data_file.write("\n")
                   break
           else:
               if (hostname_index != -1):
                   continue
               sub_marker = ip.find(" : ")
               sub_marker = sub_marker + 3    
               data_file.write(ip[sub_marker:])
               data_file.write("\n")   

#Function that connects and pulls data from network devices
def get_device_data(address):
    border = "-----------------------------"
    spacer = "--"
    #output = []
    #Prompts user for either Juniper or Cisco credentials based on User input 
    junos_device_info = {
       'ip': address,
       'port': 22,
       'username': login,
       'password': password,
       'device_type': 'juniper',
       'verbose': True
    }
    print(f'Connecting to host {address}...')
    ssh_connection = ConnectHandler(**junos_device_info)
    host_name = ssh_connection.send_command("show configuration system host-name | display set")
    host_name_trim = ssh_connection.send_command("show configuration system host-name | display set | trim 21")
    show_int = ssh_connection.send_command('show configuration interfaces | display set | match "desc|address"')
    show_int_trim = ssh_connection.send_command('show configuration interfaces | match "desc|address" | trim 20')

    command_list.append(show_int)

    with open('commands.txt', 'a+') as data_file:
        data_file.write(border + "\n" + host_name + "" + spacer + "\n" + show_int + "" + border + "\n")
      
    with open(output_file, 'a+') as data_file:
       data_file.write(border + "\n" + host_name_trim + "" + spacer + "\n" + show_int_trim + "" + border + "\n")

    ssh_connection.disconnect()
    return


def get_show_commands():
    with open('commands.txt') as devices:
        commands = devices.read().splitlines()

    organize_output(commands)


commands_list = get_show_commands()
#print(command_list)

def main():
   with concurrent.futures.ThreadPoolExecutor() as exe:
      ip_addresses = get_net_devices()
      exe.map(get_device_data, ip_addresses)
      #print(results)
   
   get_show_commands()
   #organize_output(commands_list)
   finish_time = time.perf_counter()
   print(f'The script finished executing in {round(start_time - finish_time,2)} seconds.')

   exit_script = input("Close Window or Type 'y' and press 'Enter' to exit: ")
   exit_script = exit_script.lower()
   
   if exit_script == 'y':
       exit()

if __name__ == '__main__':
   main()