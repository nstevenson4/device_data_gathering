from netmiko import ConnectHandler
import netmiko
import time
from getpass import getpass
import concurrent.futures
import datetime
#from pprint import pprint
#import json

#Variable Declarations
current_time = datetime.datetime.now().strftime('%m-%d-%Y-%H.%M.%S')
device_list = input('Enter name of device list text file: ').strip()
output_file = "juniper_finished-" + str(current_time) + ".txt"
select_device= input("Type 'y' and press ENTER if this is a Cisco device List, otherwise just press ENTER: ").strip()

if select_device.lower() == "y":
    output_file = "cisco.finished-" + str(current_time) + ".txt"

start_time = time.perf_counter()
login = input('Username: ')
password = getpass('Password: ')

command_file = "commands-" + str(current_time) + ".txt"

#Function to read values from a device IP list file
def get_net_devices():
    with open(device_list) as devices:
        addresses = devices.read().splitlines()
    return addresses

#Function that connects and pulls data from Juniper network devices
def get_juniper_data(address):
    border = ("-" * 75)
    spacer = ("-" * 15)

    #Prompts user for either Juniper or Cisco credentials based on User input 
    junos_device_info = {
       'ip': address,
       'port': 22,
       'username': login,
       'password': password,
       'device_type': 'juniper',
       'verbose': True
    }
    print(f'Connecting to host {address}...')
    ssh_connection = ConnectHandler(**junos_device_info)
    host_name = ssh_connection.send_command("show version | match hostname")
    host_name_trim = ssh_connection.send_command("show configuration system host-name | display set | trim 21", use_textfsm = True)
    show_configs_int = ssh_connection.send_command('show configuration interfaces', use_textfsm = True)

    host = (host_name_trim).strip()
    spacer = ("-" * len(host))
    configs = list(show_configs_int.split("unit"))

    with open(output_file, 'a+') as data_file:
        data_file.write(border + "\n" + host + "\n" + spacer + "\n")

        for lines in configs:
            find_addr = lines.find("address")
            find_desc = lines.find("description")
            find_end = lines.find(";")
            find_bracket = lines.find("}")
            desc = (lines[(find_desc + 12):find_end])
            address = (lines[(find_addr + 8):find_bracket]).strip()
            address = address[:-1]

            if ((find_addr != -1) and (find_desc != -1)): 
                data_file.write(host + " : " + address + " : " + desc + "\n")

            elif (find_addr != -1):
                data_file.write(host + " : " + address + "\n")

        data_file.write(border + "\n")

    ssh_connection.disconnect()
    return 

#Function that connects and pulls data from Cisco network devices
def get_cisco_data(address):
    border = ("-" * 75)
    spacer = ("-" * 15)
    #Prompts user for either Juniper or Cisco credentials based on User input 
    secret = getpass('Enable Secret: ')
    cisco_device_info = {
       'ip': address,
       #'port': 22,
       'username': login,
       'password': password,
       'device_type': 'cisco_ios',
       'secret': secret,
       'verbose': True
    }
    print(f'Connecting to host {address}...')
    ssh_connection = ConnectHandler(**cisco_device_info)
    host_name = ssh_connection.send_command("show run | include hostname")
    show_run = ssh_connection.send_command("show run | include interface|ip address|description", use_textfsm = True)

    configs = list(show_run.split("interface"))
    host = (host_name[9:])
    spacer = ("-" * len(host))

    with open(output_file, 'a+') as data_file:
        data_file.write(border + "\n" + host + "\n" + spacer + "\n")

        for lines in configs:
            find_no_addr = lines.find("no ip address")
            find_addr = lines.find("ip address")
            find_desc = lines.find("description")
            desc = (lines[(find_desc + 12):find_addr]).strip()
            address = (lines[(find_addr + 10):]).strip()

            if (find_no_addr != -1):
                continue

            if ((find_addr != -1) and (find_desc != -1)): 
                data_file.write(host + " : " + address + " : " + desc + "\n")

            elif (find_addr != -1):
                data_file.write(host + " : " + address + "\n")

        data_file.write(border + "\n")

    ssh_connection.disconnect()
    return 

def main():    
    with concurrent.futures.ThreadPoolExecutor() as exe:
        ip_addresses = get_net_devices()
        if select_device.lower() == "y":
            exe.map(get_cisco_data, ip_addresses)
        else:
            exe.map(get_juniper_data, ip_addresses)

    finish_time = time.perf_counter()
    print(f'The script finished executing in {round(start_time - finish_time,2)} seconds.')

    exit_script = input("You can either close the Window or Type 'y' and press 'Enter' to exit: ")
    exit_script = exit_script.lower()
   
    if exit_script == 'y':
        exit()

if __name__ == '__main__':
   main()